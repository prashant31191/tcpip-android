package android.vidtrailer;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;



public class BrowserActivity extends Activity {


	ProgressBar progressBar1;
	WebView myWebView;
	Bundle extras = null;
	String strFrom="",strGoogle = "http://www.Google.com";
	String strYoutube = "https://www.youtube.com/results?search_query=New movie trailer";

	LinearLayout llEnterLink;
	Button btnGo;
	EditText etLink;
	String strLastWebUrl= "http://www.Google.com";

	@SuppressLint("SetJavaScriptEnabled") @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		try {

			if(getIntent().getExtras() !=null)
			{
				extras = getIntent().getExtras(); 
			}
			

			if(extras.getString("vlink") !=null)
			{
				strGoogle = extras.getString("vlink");
			}
			if(extras.getString("from") !=null)
			{
				strFrom = extras.getString("from");
			}


		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		setContentView(R.layout.my_cust_view);
		//wv = (WebView)findViewById(R.id.webview);
		llEnterLink = (LinearLayout)findViewById(R.id.llEnterLink);
		btnGo = (Button)findViewById(R.id.btnGo);
		etLink = (EditText)findViewById(R.id.etLink);


		myWebView = (WebView) findViewById(R.id.webView1);
		progressBar1 = (ProgressBar)findViewById(R.id.progressBar1);

		progressBar1.setVisibility(View.GONE);

		btnGo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				String strLink = etLink.getText().toString();

				if (strLink.contains("http")) {
					myWebView.loadUrl(strLink);
					App.strLastUrl = strLink;
				} else {
					myWebView.loadUrl("http://" + strLink);
					App.strLastUrl = "http://" + strLink;
				}

			}
		});

		myWebView.loadUrl(strGoogle);
		App.strLastUrl =strGoogle;
		//wvContains.setBackgroundColor(Color.TRANSPARENT);

		String newUA= "Mozilla/5.0 (X11;U;Linuzi686;en-US;rv:1.9.0.4)Gecko/20100101 Firefox/4.0";
		myWebView.getSettings().setUserAgentString(newUA);
		myWebView.getSettings().setJavaScriptEnabled(true);
		myWebView.getSettings().setLoadWithOverviewMode(true);
		myWebView.getSettings().setUseWideViewPort(true);
		myWebView.getSettings().setSupportZoom(true);
		myWebView.getSettings().setBuiltInZoomControls(true);
		//myWebView.getSettings().setDefaultZoom(WebSettings.ZoomDensity.MEDIUM);

		//myWebView.getSettings().setDisplayZoomControls(true);

		myWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				view.loadUrl(url);
				System.out.println("URL-->" + url);
				App.strLastUrl = url;
				App.intLoadAds = App.intLoadAds + 1;


				if(App.intLoadAds % 6 == 0)
				{
					System.out.print("==Load Ads ===");
					Intent intent = new  Intent(BrowserActivity.this,IntAdsActivity .class);
					startActivity(intent);
				}
				else
				{

				}



				if(url.contains("https://www.youtube.com/watch?v=")) //>https://www.youtube.com/watch?v=qRv7G7WpOo
				{
					myWebView.onPause();
					myWebView.stopLoading();

					Intent intent = new Intent(BrowserActivity.this,VietPhoTvPlayActivity.class);
					intent.putExtra("vlink",url);
					startActivity(intent);
				}


				return false;
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				progressBar1.setVisibility(View.GONE);

				super.onPageFinished(view, url);
			}


			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				progressBar1.setVisibility(View.VISIBLE);

				super.onPageStarted(view, url, favicon);
			}
		});


	}
@Override
protected void onPause() {
	// TODO Auto-generated method stub
	myWebView.onPause();
	super.onPause();
}
@Override
protected void onResume() {
	// TODO Auto-generated method stub
	myWebView.onResume();
	if(App.strLastUrl != null && App.strLastUrl.length() > 5)
	{
		myWebView.loadUrl(App.strLastUrl);
	}

	super.onResume();
}
/*
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		wv.saveState(outState);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		wv.restoreState(savedInstanceState);
	}
*/
	protected void callHomeScreen(final Context context)
	{
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
		alertDialog.setCancelable(true);
		//alertDialog.setTitle("ChatsIn Exit");
		alertDialog.setMessage("Are you sure you want to Exit?");
		final AlertDialog.Builder yes = alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener() {
			@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
			public void onClick(DialogInterface dialog, int which) {
				dialog.cancel();
				finish();
				finishAffinity();
			}
		});
		alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int which) 
			{
				//finish();
				dialog.cancel();
			}
		});
		alertDialog.show();
	}


	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		//getMenuInflater().inflate(R.menu.menu_spash, menu);
		MenuItem menuItem = menu.findItem(R.id.action_settings);
		menuItem.setTitle("Static video");
		return super.onPrepareOptionsMenu(menu);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_browser, menu);
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {

		switch (item.getItemId())
		{
			case R.id.action_settings:
				finish();
				Intent intent = new Intent(BrowserActivity.this,VideoListActivity.class);
				startActivity(intent);
				break;

			case R.id.action_Google:
				myWebView.stopLoading();
				myWebView.loadUrl(strGoogle);
				App.strLastUrl =strGoogle;
				llEnterLink.setVisibility(View.GONE);

				break;

			case R.id.action_Youtube:
				myWebView.stopLoading();
				myWebView.loadUrl(strYoutube);
				App.strLastUrl =strYoutube;
				llEnterLink.setVisibility(View.GONE);
				break;


			case R.id.action_Link:
				myWebView.stopLoading();
				llEnterLink.setVisibility(View.VISIBLE);
				break;

		}
		return super.onMenuItemSelected(featureId, item);
	}

	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		
		//callHomeScreen(BrowserActivity.this);
		if(myWebView.canGoBack())
		{
			myWebView.goBack();
		}
		else if(strFrom !=null && strFrom.equalsIgnoreCase("main"))
		{
		 finish();
		}
		else
		{
			finish();
			Intent intent = new Intent(BrowserActivity.this,VideoListActivity.class);
			startActivity(intent);
		}
	}


}













