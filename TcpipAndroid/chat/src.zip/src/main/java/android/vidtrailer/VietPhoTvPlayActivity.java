package android.vidtrailer;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;


public class VietPhoTvPlayActivity extends Activity {

	private MyWebChromeClient mWebChromeClient = null; 
	private View mCustomView;
	private RelativeLayout mContentView;
	private FrameLayout mCustomViewContainer; 
	private WebChromeClient.CustomViewCallback mCustomViewCallback;

	ProgressBar progressBar1;

LinearLayout llEnterLink;
	WebView myWebView;
	Bundle extras = null;
	String strLoadVideo = "http://www.youtube.com/embed/175Bq3MSrWo";
	@SuppressLint("SetJavaScriptEnabled") @Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		try {
			
			getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN);

			if(getIntent().getExtras() !=null)
			{
				extras = getIntent().getExtras(); 
			}
			

			if(extras.getString("vlink") !=null)
			{
				String strPrevLink = "",strPrevLink2="";
				strPrevLink = extras.getString("vlink");

				if(strPrevLink.contains("watch?v="))
				{
					System.out.println("Replace text");
					System.out.println("-link is1 -->" + strPrevLink);
					strPrevLink = strPrevLink.replace("watch?v=", "embed/");
					System.out.println("-link is2 -->" + strPrevLink);
					//strPrevLink.replaceAll("watch?v=","embed/");


				}


				strLoadVideo =strPrevLink ;

				System.out.println("-link is -->" + strPrevLink);

				// -- https://www.youtube.com/watch?v=qRv7G7WpOoU
				// -- http://www.youtube.com/embed/175Bq3MSrWo
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
		
		setContentView(R.layout.my_cust_view);


		//wv = (WebView)findViewById(R.id.webview);
		llEnterLink = (LinearLayout)findViewById(R.id.llEnterLink);
		myWebView = (WebView) findViewById(R.id.webView1);
		progressBar1 = (ProgressBar)findViewById(R.id.progressBar1);
		
		progressBar1.setVisibility(View.VISIBLE);
		llEnterLink.setVisibility(View.GONE);
		
		
		mWebChromeClient = new MyWebChromeClient();
		myWebView.setWebChromeClient(mWebChromeClient);
		
		

		myWebView.getSettings().setJavaScriptEnabled(true);
		String strMimetype="text/html";
		String strencoding="UTF-8";
		String strHtml = ""+getHtmpVideo();
/*
		wv.setWebChromeClient(new WebChromeClient()
		{});*/

		//myWebView.loadDataWithBaseURL("", strHtml, strMimetype, strencoding, "");  

		myWebView.loadUrl(strLoadVideo);
		

	    new Handler().postDelayed(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				
			}
		},2000);

	}
@Override
protected void onPause() {
	// TODO Auto-generated method stub
	myWebView.onPause();
	super.onPause();
}
@Override
protected void onResume() {
	// TODO Auto-generated method stub
	myWebView.onResume();
	super.onResume();
}
/*
	@Override
	protected void onSaveInstanceState(Bundle outState) {
		// TODO Auto-generated method stub
		super.onSaveInstanceState(outState);
		wv.saveState(outState);
	}

	@Override
	protected void onRestoreInstanceState(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onRestoreInstanceState(savedInstanceState);
		wv.restoreState(savedInstanceState);
	}
*/
	private String getHtmpVideo()
	{
		String strData = "";

		/*strData = "<html>" +
    	"<iframe src=\"http://www.ustream.tv/embed/21681543?html5ui&showtitle=false\" style=\"border: 0 none transparent;\" webkitallowfullscreen allowfullscreen frameborder=\"no\" width=\"480\" height=\"270\"></iframe>"
    			+"</html>";
		 */		
		strData = "<html>" +
				"<iframe src=\"http://www.ustream.tv/embed/21681543?html5ui&showtitle=false\" style=\"border: 0 none transparent;\" webkitallowfullscreen allowfullscreen frameborder=\"no\"></iframe>"
				+"</html>";


		return strData;

	}










	private class MyWebChromeClient extends WebChromeClient
	{ 
		FrameLayout.LayoutParams LayoutParameters = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT); 
		@Override 
		public void onShowCustomView(View view, CustomViewCallback callback)
		{ // if a view already exists then immediately terminate the new one 
			if (mCustomView != null) 
			{ 
				callback.onCustomViewHidden(); 
				return; 
			}
			try {
				
				mContentView = (RelativeLayout) findViewById(R.id.rlMyView); 
				mContentView.setVisibility(View.GONE); 
				mCustomViewContainer = new FrameLayout(VietPhoTvPlayActivity.this); 
				mCustomViewContainer.setLayoutParams(LayoutParameters); 
				mCustomViewContainer.setBackgroundResource(android.R.color.black); 
				view.setLayoutParams(LayoutParameters); 
				
				mCustomViewContainer.addView(view); 
				mCustomView = view;
				mCustomViewCallback = callback; 
				mCustomViewContainer.setVisibility(View.VISIBLE); 
				setContentView(mCustomViewContainer);
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("==Err=1===");
				e.printStackTrace();
			}
			 } 
		@Override 
		public void onHideCustomView() 
		{ if (mCustomView == null) 
		{ return; 
		} 
		else 
		{
			try {

				// Hide the custom view. 
				mCustomView.setVisibility(View.GONE); 
				// Remove the custom view from its container. 
				mCustomViewContainer.removeView(mCustomView); 
				mCustomView = null; 
				mCustomViewContainer.setVisibility(View.GONE); 
				mCustomViewCallback.onCustomViewHidden(); 
				// Show the content view. 
				mContentView.setVisibility(View.VISIBLE); 
			//	setContentView(mContentView); 
				
			} catch (Exception e) {
				// TODO: handle exception
				System.out.println("==Err=2===");
				e.printStackTrace();
			}
			
		}
		}
		
		@Override
		public void onReceivedTitle(WebView view, String title) {
			// TODO Auto-generated method stub
			super.onReceivedTitle(view, title);
			progressBar1.setVisibility(View.GONE);
		}

	}





	protected void callHomeScreen(final Context context)
	{
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
		alertDialog.setCancelable(true);
		//alertDialog.setTitle("ChatsIn Exit");
		alertDialog.setMessage("Are you sure you want to Exit?");
		alertDialog.setPositiveButton("YES", new DialogInterface.OnClickListener()
		{
			@TargetApi(Build.VERSION_CODES.JELLY_BEAN)
			public void onClick(DialogInterface dialog,int which)
			{dialog.cancel(); 
				finish();
				finishAffinity();
				/*dialog.cancel(); 
				Intent startMain = new Intent(Intent.ACTION_MAIN);
				startMain.addCategory(Intent.CATEGORY_HOME);
				startMain.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				context.startActivity(startMain);*/
			}
		});
		alertDialog.setNegativeButton("NO", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int which) 
			{
				//finish();
				dialog.cancel();
			}
		});
		alertDialog.show();
	}






/*
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_spash, menu);
		return true;
	}*/


	@Override
	public void onBackPressed() {
		// TODO Auto-generated method stub
		myWebView.onPause();
		myWebView.stopLoading();
		finish();
		//callHomeScreen(VietPhoTvPlayActivity.this);
		
		
		
	}









}













