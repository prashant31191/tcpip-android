package android.vidtrailer;

public class YouPlayModel {

	
	public String strVideoId= "";
	public String strVideoLink = "";
	public String strVideoTitle = "";
	
	
}
