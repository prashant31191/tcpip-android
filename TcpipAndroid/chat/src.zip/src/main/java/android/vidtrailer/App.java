package android.vidtrailer;

/**
 * Created by Prashant on 09-03-2016.
 */
public class App {

    public static int intLoadAds = 0;

    public static String strLastUrl = "";
}
