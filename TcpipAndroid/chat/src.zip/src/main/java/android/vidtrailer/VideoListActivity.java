package android.vidtrailer;

import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Display;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.ListView;

public class VideoListActivity extends Activity
{
	LinearLayout llListCust;
	ListView lvVideos;
	ArrayList<YouPlayModel> arrListYouPlay;


int width=420;
int height=330;



	@SuppressLint({ "SetJavaScriptEnabled", "NewApi" })
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);

		setContentView(R.layout.act_video_list);
		
		try {
			Display display = getWindowManager().getDefaultDisplay();
			Point sizePoint = new Point();
			display.getSize(sizePoint);
			
			width = sizePoint.x ;
			height = sizePoint.y;
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		

		lvVideos = (ListView)findViewById(R.id.lvVideos);
		llListCust = (LinearLayout)findViewById(R.id.llListCust);

		String [] arrVideoLinkList = {
				"http://www.youtube.com/embed/175Bq3MSrWo",
				"http://www.youtube.com/embed/eDgUgY8lKlk",
				"http://www.youtube.com/embed/xe1LrMqURuw",
				"http://www.youtube.com/embed/UgBWSPD6MUU",	
		};

		String [] arrVideoTitleList = {
				"AngryBird - 2",
				"KunfuPanda -3",
				"Teg Tailer",
				"Study Video",	
		};

		arrListYouPlay = new  ArrayList<YouPlayModel>();
		for (int i = 0; i < arrVideoLinkList.length; i++) {
			YouPlayModel youPlayModel = new  YouPlayModel();

			youPlayModel.strVideoId = ""+i;
			youPlayModel.strVideoTitle  = getHtmpVideo(arrVideoTitleList[i]);
			youPlayModel.strVideoLink = arrVideoLinkList[i];

			arrListYouPlay.add(youPlayModel);

		}


		if(arrListYouPlay !=null && arrListYouPlay.size() > 1)
		{
			LayoutParams llParam = new  LayoutParams(width, width+100);
			for (int i = 0; i < arrListYouPlay.size(); i++) {

				WebView myWebView = new  WebView(this);
				
				myWebView.setLayoutParams(llParam);
				//myWebView.loadUrl(arrListYouPlay.get(i).strVideoLink);

				myWebView.getSettings().setJavaScriptEnabled(true);



				String newUA= "Mozilla/5.0 (X11;U;Linuzi686;en-US;rv:1.9.0.4)Gecko/20100101 Firefox/4.0";
				myWebView.getSettings().setUserAgentString(newUA);
				myWebView.getSettings().setJavaScriptEnabled(true);
				myWebView.getSettings().setLoadWithOverviewMode(true);
				myWebView.getSettings().setUseWideViewPort(true);
				myWebView.getSettings().setSupportZoom(true);
				myWebView.getSettings().setBuiltInZoomControls(true);


				String strMimetype="text/html";
				String strencoding="UTF-8";
				String strHtml = getHtmpVideo("");

				myWebView.setWebChromeClient(new WebChromeClient()
				{});
				//myWebView.loadDataWithBaseURL("", strHtml, strMimetype, strencoding, "");
				myWebView.loadUrl(arrListYouPlay.get(i).strVideoLink);
				myWebView.setTag(arrListYouPlay.get(i).strVideoLink);
				//myWebView.loadUrl(strHtml);
				

				myWebView.setOnClickListener(new OnClickListener() {
					
					@Override
					public void onClick(View v) {
						// TODO Auto-generated method stub
						System.out.println("==Click==");
						//Intent intVietPhoTvPlayActivity = new  Intent(VideoListActivity.this,VietPhoTvPlayActivity.class);
						//intVietPhoTvPlayActivity.putExtra("vlink", ""+v.getTag());
						System.out.println("==Click="+v.getTag());
					}
				});
				
				
				llListCust.addView(myWebView);
				
				
			}

		}


		/*		if(arrListYouPlay !=null && arrListYouPlay.size() > 1)
		{
			VideoListAdapter videoListAdapter = new  VideoListAdapter(VideoListActivity.this, arrListYouPlay);

			lvVideos.setAdapter(videoListAdapter);
		}*/


	}


	private String getHtmpVideo(String strLink)
	{
		{ 
			String html = "<iframe class=\"youtube-player\" style=\"border: 0; width: 100%; height: 95%; padding:0px; margin:0px\" id=\"ytplayer\" type=\"text/html\" src=\"" +
					"http://www.youtube.com/embed/" + "k8GzqXg2ugA" 
					+ "?fs=0\" frameborder=\"0\">\n" + "</iframe>\n"; return html; 
		}
		}



		/*
	private class VideoListAdapter extends BaseAdapter
	{
		ArrayList<YouPlayModel> mArrListYouPlay;
		Context  mContext;
		private LayoutInflater inflater;

		private  VideoListAdapter(Context  context,ArrayList<YouPlayModel> arrListYouPlay)
		{
			mArrListYouPlay = arrListYouPlay;
			mContext = context;
			inflater = LayoutInflater.from(context);
		}
		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return mArrListYouPlay.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return mArrListYouPlay.get(position);
		}

		@Override	
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return mArrListYouPlay.size();
		}

		@SuppressLint("SetJavaScriptEnabled")
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			ViewHolder holder;
			if(convertView == null)
			{
				convertView=inflater.inflate(R.layout.adapter_webview, null);
				holder = new ViewHolder();

				convertView.setTag(holder);

				holder.tvVideoTitle = (TextView)convertView.findViewById(R.id.tvVideoTitle);
				holder.myWebView = (WebView) findViewById(R.id.webView1);
			}
			else
			{
				holder = (ViewHolder)convertView.getTag();
			}
			holder.tvVideoTitle.setText(mArrListYouPlay.get(position).strVideoTitle);
			holder.myWebView.getSettings().setJavaScriptEnabled(true);
			holder.myWebView.setWebChromeClient(new WebChromeClient(){});
			holder.myWebView.loadUrl(mArrListYouPlay.get(position).strVideoLink);

			return convertView;
		}  


		class ViewHolder
		{
			TextView tvVideoTitle;
			WebView myWebView;
		}

	}
		 */



	@Override
	public boolean onPrepareOptionsMenu(Menu menu) {
		//getMenuInflater().inflate(R.menu.menu_spash, menu);
		MenuItem menuItem = menu.findItem(R.id.action_settings);
		menuItem.setTitle("Open browser");

		return super.onPrepareOptionsMenu(menu);
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_spash, menu);
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {

		switch (item.getItemId())
		{
			case R.id.action_settings:
				finish();
				Intent intent = new  Intent(VideoListActivity.this,BrowserActivity.class);
				startActivity(intent);
				break;

		}
		return super.onMenuItemSelected(featureId, item);


	}


}
