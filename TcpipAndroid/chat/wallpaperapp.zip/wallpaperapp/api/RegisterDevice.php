<?php 
	require_once 'DbOperation.php';
	$response = array(); 

	//if($_SERVER['REQUEST_METHOD']=='POST'){

		$token = $_REQUEST['token'];
		$email = $_REQUEST['email'];

		$db = new DbOperation(); 

		$result = $db->registerDevice($email,$token);

		if($result == 0){
			$response['code'] = 1; 
			$response['message'] = 'Device registered successfully';
		}elseif($result == 2){
			$response['code'] = 2; 
			$response['message'] = 'Device already registered';
		}else{
			$response['code'] = 0;
			$response['message']='Device not registered';
		}
/*	}else{
		$response['code']=404;
		$response['message']='Invalid Request...';
	}*/

	echo json_encode($response);