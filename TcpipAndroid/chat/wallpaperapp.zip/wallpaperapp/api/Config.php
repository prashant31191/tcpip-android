<?php 
	define('DB_USERNAME','b7_21131689');
	define('DB_PASSWORD','Hello@135');
	define('DB_NAME','b7_21131689_socialapp');
	define('DB_HOST','sql303.byethost7.com');

//defined a new constant for firebase api key
 define('FIREBASE_API_KEY', 'AAAA8Y-nxy4:APA91bFceh_w0EYLaIhIGEVCRHEStMpITFCU_-dINK9C3e6k1nHKEE78hp0b8uOXOPbloaJA6auFv_wk2P3lLLLejTwniLan20XzOdqba_GxsLWn3znKyjVl_YlxmbgxpS9gnAHPu6hn');