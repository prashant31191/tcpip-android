<?php 
//importing required files 
require_once 'DbOperation.php';
require_once 'Firebase.php';
require_once 'Push.php'; 

$db = new DbOperation();

$response = array(); 

// if($_SERVER['REQUEST_METHOD']=='POST'){	
	//hecking the required params 
	if(isset($_REQUEST['title']) and isset($_REQUEST['message']) and isset($_REQUEST['email'])){

		//creating a new push
		$push = null; 
		//first check if the push has an image with it
		if(isset($_POST['image'])){
			$push = new Push(
					$_REQUEST['title'],
					$_REQUEST['message'],
					$_REQUEST['image']
				);
		}else{
			//if the push don't have an image give null in place of image
			$push = new Push(
					$_REQUEST['title'],
					$_REQUEST['message'],
					null
				);
		}

		//getting the push from push object
		$mPushNotification = $push->getPush(); 

		//getting the token from database object 
		$devicetoken = $db->getTokenByEmail($_REQUEST['email']);

		//creating firebase class object 
		$firebase = new Firebase(); 

		//sending push notification and displaying result 
		echo $firebase->send($devicetoken, $mPushNotification);
	}else{
		$response['error']=true;
		$response['message']='Parameters missing';
	}/*
}else{
	$response['error']=true;
	$response['message']='Invalid request';
}*/

echo json_encode($response);